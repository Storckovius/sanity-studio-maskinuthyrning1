import kategori from './kategori'
import utrustning from './utrustning'

export const schemaTypes = [kategori, utrustning]
