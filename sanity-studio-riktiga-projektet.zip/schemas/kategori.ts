export default {
  name: 'kategori',
  title: 'Kategorier',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Namn',
      type: 'string'
    }
  ]
}
