export default {
  name: 'utrustning',
  title: 'Utrustning',
  type: 'document',
  fields: [
    {
      name: 'name',
      title: 'Namn',
      type: 'string'
    },
    {
      name: 'description',
      title: 'Beskrivning',
      type: 'text'
    },
    {
      name: 'category',
      title: 'Kategori',
      type: 'reference',
      to: [{ type: 'kategori' }]
    }
  ]
}
